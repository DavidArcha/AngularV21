import { inject, NgModule, provideAppInitializer, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import {
  TranslateModule,
  provideTranslateService,
  provideMissingTranslationHandler,
} from '@ngx-translate/core';
import { provideTranslateHttpLoader } from '@ngx-translate/http-loader';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { LanguageService, AppMissingTranslationHandler } from './services/language-service';

@NgModule({
  declarations: [App],
  imports: [BrowserModule, AppRoutingModule, TranslateModule],
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideHttpClient(),

    // ngx-translate configuration
    provideTranslateService({
      loader: provideTranslateHttpLoader({
        prefix: './assets/i18n/',
        suffix: '.json',
      }),
      missingTranslationHandler: provideMissingTranslationHandler(AppMissingTranslationHandler),
      fallbackLang: 'en',
    }),

    // Initialize LanguageService at app startup (Angular 21 way)
    provideAppInitializer(() => inject(LanguageService).init()),
  ],
  bootstrap: [App],
})
export class AppModule {}
