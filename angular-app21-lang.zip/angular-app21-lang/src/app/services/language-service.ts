import { Injectable, inject } from '@angular/core';
import {
  TranslateService,
  MissingTranslationHandler,
  MissingTranslationHandlerParams,
} from '@ngx-translate/core';

// ============================================
// CONFIGURATION - Easy to change
// ============================================
export const LANGUAGES = ['en', 'de'] as const;
export type Language = (typeof LANGUAGES)[number];
export const DEFAULT_LANGUAGE: Language = 'en';
const STORAGE_KEY = 'app-language';

// ============================================
// MISSING TRANSLATION HANDLER
// Returns the key if translation is not found
// ============================================
export class AppMissingTranslationHandler implements MissingTranslationHandler {
  handle(params: MissingTranslationHandlerParams): string {
    console.warn(`Missing translation: "${params.key}"`);
    return params.key;
  }
}

// ============================================
// LANGUAGE SERVICE - Main service for i18n
// ============================================
@Injectable({
  providedIn: 'root',
})
export class LanguageService {
  private translate = inject(TranslateService);

  /** Current language */
  get currentLanguage(): Language {
    return this.translate.currentLang as Language;
  }

  /** All supported languages */
  get languages(): readonly Language[] {
    return LANGUAGES;
  }

  /**
   * Initialize - call once at app startup
   */
  init(): void {
    this.translate.addLangs([...LANGUAGES]);
    this.translate.setFallbackLang(DEFAULT_LANGUAGE);

    const lang = this.getSavedLanguage() || this.getBrowserLanguage() || DEFAULT_LANGUAGE;
    this.setLanguage(lang);
  }

  /**
   * Switch language at runtime
   */
  setLanguage(lang: Language): void {
    if (!LANGUAGES.includes(lang)) {
      lang = DEFAULT_LANGUAGE;
    }

    this.translate.use(lang);
    localStorage.setItem(STORAGE_KEY, lang);
    document.documentElement.lang = lang;
  }

  /**
   * Get translation instantly (for use in TypeScript)
   */
  instant(key: string, params?: Record<string, unknown>): string {
    return this.translate.instant(key, params);
  }

  // --- Private helpers ---

  private getSavedLanguage(): Language | null {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved && LANGUAGES.includes(saved as Language) ? (saved as Language) : null;
  }

  private getBrowserLanguage(): Language | null {
    const browserLang = navigator.language?.split('-')[0];
    return browserLang && LANGUAGES.includes(browserLang as Language)
      ? (browserLang as Language)
      : null;
  }
}
