import { Component, inject, signal } from '@angular/core';
import { LanguageService, type Language } from './services/language-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.scss',
})
export class App {
  protected readonly title = signal('angular-app21');

  // Inject LanguageService for runtime language switching
  protected readonly langService = inject(LanguageService);

  // Current language
  protected get currentLanguage(): Language {
    return this.langService.currentLanguage;
  }

  // List of supported languages
  protected get supportedLanguages(): readonly Language[] {
    return this.langService.languages;
  }

  // Switch language at runtime
  protected switchLanguage(lang: Language): void {
    this.langService.setLanguage(lang);
  }
}
